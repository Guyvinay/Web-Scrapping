from scrapper import Scrapper

def main():

    #Getting instance of Scrapper
    scrapper = Scrapper()

    #Executing the runScrapper function of Scrapper
    scrapper.runScrapper()

if __name__=='__main__':
    main()    